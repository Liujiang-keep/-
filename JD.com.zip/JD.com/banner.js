/**
 * areaDom content2轮播图区域
 * options 配置
 */
function creatBannerArea(areaDom , options){
	var imgArea = document.createElement("div");
	var numberArea = document.createElement("div");		//角标
	var curIndex = 0;//显示第几张图片
	var changeTimer=null;//自动切换计时器
	var changeDuration = 3000; //3秒间隔
	var timer=null;//动画计时器
	//创建区域，显示图片
	initImgs();
	
	//创建区域 角标，
	initNumbers();
	
	setStatus();
	
	autochange();
	/**
	 * 初始化图片区域
	 */
	
	function initImgs(){
		imgArea.style.width="100%";
		imgArea.style.height="100%";
		imgArea.style.display="flex";
		imgArea.style.overflow="hidden";
		for(let i=0;i<options.length;i++){
			var obj=options[i];
			var img=document.createElement("img")
			img.src=obj.imgUrl;
			img.style.width="100%";
			img.style.height="100%";
			imgArea.appendChild(img);
			img.style.marginLeft="0px";
			img.style.cursor="pointer";
			img.addEventListener("click" ,function(){
				location.href=options[i].link;
			})
		}
		areaDom.addEventListener("mouseenter",function(){
			clearInterval(changeTimer);
			changeTimer=null;
		})
		areaDom.addEventListener("mouseleave",function(){
			autochange();
		})
		areaDom.appendChild(imgArea);
	}
	
	function initNumbers(){
		numberArea.style.textAlign="center"
		numberArea.style.marginTop="-25px"
		for (var i = 0; i < options.length; i++) {   //var 改let   或者用立即执行函数闭包
			var sp=document.createElement("span");
			sp.style.width="12px";
			sp.style.height="12px";
			sp.style.background="lightgray";
			sp.style.display="inline-block";
			sp.style.margin="6px"
			sp.style.borderRadius="20px"
			sp.style.cursor="pointer";
			// 立即执行函数闭包
			(function(index){
				sp.addEventListener("click", function(){
					curIndex=index;
					setStatus();
				})
			})(i)
// 			sp.addEventListener("click", function(){
// 				curIndex=i;
// 				setStatus();
// 			})
			numberArea.appendChild(sp);
		}
		areaDom.appendChild(numberArea);
	}
	//设置状态
	function setStatus(){
		//设置小圆点背景
		for (var i = 0; i < numberArea.children.length; i++) {
			if (i === curIndex) {
				numberArea.children[i].style.background="white";
			} else{
				numberArea.children[i].style.background="lightgray";
			}
		}
		//图片
		var start = parseInt(imgArea.children[0].style.marginLeft);
		
		var end=curIndex* -100;
		var dis = end - start;
		var duration = 500;
		var speed = dis / duration;
		if(timer){
			clearInterval(timer);
		}
		timer = setInterval(function(){
			start +=speed*20;
			imgArea.children[0].style.marginLeft = start + "%";
			if (Math.abs(end-start)<1) {
				imgArea.children[0].style.marginLeft = end + "%";
				clearInterval(timer);
			}
		},20)
		
	}
	
	function autochange(){
		if(changeTimer){
			return;
		}
		changeTimer = setInterval(function(){
			if (curIndex === options.length - 1) {
				curIndex=0;
			} else{
				curIndex++;				
			}
			setStatus();
		},changeDuration)
	}
	
}
	

